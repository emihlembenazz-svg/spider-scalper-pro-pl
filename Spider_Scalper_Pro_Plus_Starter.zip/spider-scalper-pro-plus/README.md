# Spider Scalper Pro+ — EA Hosting Hub (Starter)

This is a responsive front-end prototype for an MT5 EA hosting/library website. It is designed to open on desktop and mobile browsers.

## Run it
1. Download and unzip the project.
2. Open `index.html` in a browser, or upload the folder to a static website host.
3. For a quick public preview, create a GitHub repository, upload these files, then enable GitHub Pages in the repository's Settings → Pages.

## Important prototype limitations
- The sign-in button is a demo message, not real authentication.
- EA listings exist only in the current browser session; they are not stored on a server.
- The file picker does not upload files to the internet. The download button downloads the file selected in that browser.
- There is no real VPS/MT5 execution, customer billing, password reset, admin console, or iOS/Android app build.
- Do not collect customers' broker passwords or MT5 trading credentials in this prototype.

## To make it a real service
A production build needs:
1. **Authentication:** a provider such as Supabase Auth or Firebase Auth.
2. **Private file storage:** Supabase Storage or S3-compatible storage, with file-size limits, access rules, malware scanning, and signed download URLs.
3. **Database:** store EA metadata, owner ID, version, access level, and audit events.
4. **Backend API:** validate uploads server-side; never trust browser-only checks.
5. **Hosting workers:** separate Windows VPS/VMs for MT5 terminals. Each customer/session needs isolation and explicit broker/platform permissions. A website server alone does not run MT5 EAs.
6. **Billing and legal:** only if needed; publish clear terms, privacy policy, risk disclosures, and refund rules.
7. **Mobile apps:** package a secure API-backed mobile app (for example with React Native/Expo) after the backend is stable.

## Suggested deployment path
- Frontend prototype: GitHub Pages or Vercel.
- Backend and auth: Supabase or a similar service.
- MT5 runtime: Windows VPS provider, provisioned separately from the website.
- Domain: purchase a domain after testing.

## Suggested first production milestone
Implement sign-up/sign-in, private EA uploads, and owner-only downloads first. Add VPS hosting only after secure file management works and has been tested. This project does not promise trading results or financial returns.
