const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');
menuToggle.addEventListener('click', () => nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => nav.classList.remove('open')));

const signInDialog = document.getElementById('signInDialog');
document.getElementById('signInBtn').addEventListener('click', () => signInDialog.showModal());

const fileInput = document.getElementById('eaFile');
const fileName = document.getElementById('fileName');
const toast = document.getElementById('toast');
let toastTimer;
function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
}
fileInput.addEventListener('change', () => {
  fileName.textContent = fileInput.files[0] ? fileInput.files[0].name : '.ex5 or .mq5 · select a file';
});

document.getElementById('eaForm').addEventListener('submit', event => {
  event.preventDefault();
  const file = fileInput.files[0];
  if (!file) return showToast('Choose an EA file first.');
  const ext = file.name.toLowerCase().split('.').pop();
  if (!['ex5', 'mq5'].includes(ext)) return showToast('Please select an .ex5 or .mq5 file.');
  const name = document.getElementById('eaName').value.trim();
  const version = document.getElementById('eaVersion').value.trim();
  const description = document.getElementById('eaDescription').value.trim();
  const card = document.createElement('article');
  card.className = 'listing-card';
  const versionLabel = document.createElement('div');
  versionLabel.className = 'listing-meta';
  versionLabel.textContent = `MT5 · Version ${version}`;
  const title = document.createElement('h3');
  title.textContent = name;
  const desc = document.createElement('p');
  desc.textContent = description || 'No description provided.';
  const fileInfo = document.createElement('p');
  fileInfo.textContent = `Selected file: ${file.name}`;
  const download = document.createElement('a');
  download.className = 'download-btn';
  download.href = URL.createObjectURL(file);
  download.download = file.name;
  download.textContent = 'Download selected file ↓';
  card.append(versionLabel, title, desc, fileInfo, download);
  const listing = document.getElementById('eaListings');
  const empty = listing.querySelector('.empty-state');
  if (empty) empty.remove();
  listing.prepend(card);
  document.getElementById('eaForm').reset();
  fileName.textContent = '.ex5 or .mq5 · select a file';
  showToast('Demo listing created in this browser. It is not uploaded to a server.');
  document.getElementById('library').scrollIntoView({ behavior: 'smooth' });
});